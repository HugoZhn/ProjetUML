package vue;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import model.*;

import utilitaire.OldDataExtractor;
import utilitaire.Date;
import utilitaire.TimeParser;

import java.awt.*;
import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import model.*;

import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import java.awt.TextField;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.Component;
import java.awt.GridBagLayout;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.Icon;
import java.awt.Label;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.ScrollPane;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VueClassement {

    private JFrame frame;
    private JTable table;
    private JTextField txtHttpffragfrclassementdfinitifrallye;
    private JTextField txtSearch;
    private JTable table_1;
    private TableModel data;
    private TableColumnModel entetes;
    private JTable table_2;
    private Edition editionConcerne;
    private java.awt.Panel panel1;
    private java.awt.Panel panelbig ;

    public VueClassement(Edition[] classementEditions) {

        frame = new JFrame();
        frame.setBounds(100, 100, 971, 630);
        frame.getContentPane().setBackground(Color.white) ;
        frame.setTitle("Classement définitif des rallyes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        txtHttpffragfrclassementdfinitifrallye = new JTextField("url", SwingConstants.CENTER);
        txtHttpffragfrclassementdfinitifrallye.setEditable(false);
        txtHttpffragfrclassementdfinitifrallye.setFont(new Font("Cambria", Font.CENTER_BASELINE, 12));
        txtHttpffragfrclassementdfinitifrallye.setText("https://FFRAG.fr/ClassementDefinitifRallye.html");
        txtHttpffragfrclassementdfinitifrallye.setBounds(310, 25, 290, 25);
        frame.getContentPane().add(txtHttpffragfrclassementdfinitifrallye);
        txtHttpffragfrclassementdfinitifrallye.setColumns(8);
        panel1 = new java.awt.Panel();
        panel1.setBackground(new java.awt.Color(100, 189, 189));
        panel1.setForeground(new java.awt.Color(100, 189, 189));
        panel1.setBounds(1, 1, 972, 70);
        frame.getContentPane().add(panel1);
         
        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(212, 135, 534, 300);
        scrollPane_1.setBackground(Color.white);
        frame.getContentPane().add(scrollPane_1);

        table_2 = new JTable();
        table_2.setColumnSelectionAllowed(true);
        table_2.setGridColor(new java.awt.Color(100, 189, 189));
        table_2.setCellSelectionEnabled(true);
        table_2.setFont(new Font("Cambria", Font.PLAIN, 13));
        table_2.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        table_2.setRowHeight(20);
        table_2.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        table_2.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Position", "Participant", "Temps"
                }
        ));
        scrollPane_1.setViewportView(table_2);

        Label label_2 = new Label("Classement d\u00E9finitif", SwingConstants.CENTER);
        label_2.setFont(new Font("Cambria", Font.PLAIN, 25));
        label_2.setForeground(new java.awt.Color(100, 189, 189));
        label_2.setBounds(340, 90, 230, 30);
        frame.getContentPane().add(label_2);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(23, 167, 145, 83);
        scrollPane.setBackground(Color.WHITE);
        frame.getContentPane().add(scrollPane);

        //Afficher le nom des rallyes dans une liste
        Object[] listeRallye = null;
        
        listeRallye = new Object[]{classementEditions[0].getEditionDe().getNomRallye(), classementEditions[1].getEditionDe().getNomRallye()};

        //Crꢴion de la liste
        JList list_1 = new JList(listeRallye);
        scrollPane.setViewportView(list_1);
        list_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list_1.setForeground(new java.awt.Color(100, 189, 189));
        list_1.setLayoutOrientation(JList.VERTICAL);

        JLabel lbl_2 = new JLabel();
        lbl_2.setBounds(341, 103, 130, 20);
        frame.getContentPane().add(lbl_2);

        //Rꤵp곥r la valeur sꭥctionnꥠdans la liste
        list_1.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                lbl_2.setText((String) list_1.getSelectedValue()); //nomRallye    		 
            }
        });

        //Crꢴion du bouton classement
        JButton btnClassement = new JButton("Classement");
        btnClassement.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int i;
                Participant participant = null;
                double temps = 0;

                //Rꪮitialiser le tableau ࡳa valeur de d걡rt sur chaque clic
                table_2.setModel(new DefaultTableModel(new Object[][]{}, new String[]{"Position", "Participant", "Temps"}
                ));
                scrollPane_1.setViewportView(table_2);

                DefaultTableModel model = (DefaultTableModel) table_2.getModel(); 
                //Object[] edition = {list_1.getSelectedValue()} ;

                for (Edition ed : classementEditions) {
                    if (ed.getEditionDe().getNomRallye().equals(list_1.getSelectedValue())) {
                        for (i = 0; i < ed.getClassement().size(); i++) {
                            participant = ed.getClassement().get(i);
                            temps = ed.getClassement().get(i).getTempsFinal();
                            TimeParser joliTemps = new TimeParser(temps);
                            Object[] row = {i + 1, participant, joliTemps};
                            model.addRow(row);
                        }
                    }
                }
            }
        }
        );

        btnClassement.setBounds(390, 440, 139, 23);
        frame.getContentPane().add(btnClassement);
    
    
    
        JLabel label = new JLabel(new ImageIcon(".\\img\\ffrag2.png"));
        label.setText("");
        label.setForeground(new Color(100, 189, 189));
        label.setBackground(new Color(100, 189, 189));
        label.setBounds(700, 340, 300, 300);
        frame.getContentPane().add(label) ;
                
                }

    public JFrame getFrame() {
        return frame;
    }
    
}