package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Etape {

    private Edition etapeDe;
    private int codeEtape;
    private double distanceEtape;
    private boolean classementValid;

    private HashMap<Participant, Double> courir;
    private HashMap<Participant, Double> courirTempsCorriges;
    private ArrayList<Participant> classement;

    /**
     * Constructeur d'une étape
     * @param etapeDe étape à laquelle l'édition appartient
     * @param distanceEtape 
     */
    public Etape(Edition etapeDe, double distanceEtape) {
        this.codeEtape = etapeDe.getEtapes().size();
        etapeDe.getEtapes().add(this);
        this.etapeDe = etapeDe;
        this.distanceEtape = distanceEtape;
        this.classementValid = false;

        this.courir = new HashMap<Participant, Double>();
        this.courirTempsCorriges = new HashMap<Participant, Double>();
        this.classement = new ArrayList<>();
    }

    public int getCodeEtape() {
        return codeEtape;
    }

    public double getDistanceEtape() {
        return distanceEtape;
    }

    public boolean isClassementValid() {
        return classementValid;
    }

    public HashMap<Participant, Double> getCourir() {
        return courir;
    }

    public HashMap<Participant, Double> getCourirTempsCorriges() {
        return courirTempsCorriges;
    }
    
    public ArrayList<Participant> getClassement() {
        this.calculerClassement();
        return this.classement;
    }

    /**
     * Méthode permettant d'affecter un temps à un participant. 
     * Le temps sera corrigé en fonction du coeff correspondand au véhicule utilisé
     * @param part
     * @param temps 
     */
    public void affecterTemps(Participant part, double temps) {
        this.courir.put(part, temps);
        this.courirTempsCorriges.put(part, temps * part.getCoeffCorrecteurVehicule());
    }

    /**
     * Calcul du classement de l'étape. 
     * Tous les participants ayant pris un départ seront triés en fonctions de leur temps corrigé
     * Le classement ne peut pas être recalculé après sa validation.
     */
    private void calculerClassement() {
        if (!classementValid) {
            this.classement.clear();
            for (Participant part : this.courirTempsCorriges.keySet()) {
                if (part.prendreDepart()) {
                    this.classement.add(part);
                }
            }
            boolean changement = true;
            while (changement) {
                changement = false;
                for (int i = 0; i < this.classement.size() - 1; i++) {
                    if (this.courirTempsCorriges.get(this.classement.get(i)) > this.courirTempsCorriges.get(this.classement.get(i + 1))) {
                        Collections.swap(this.classement, i, i + 1);
                        changement = true;
                    }
                }
            }
        }
    }

    /**
     * On valide le classement avec les temps corrigé. Le classement n'est plus provisoire et est dévoilé
     */
    public void validerClassement() {
        this.calculerClassement();
        this.classementValid = true;
    }

    public String toString() {
        return String.valueOf(this.codeEtape + 1);
    }

}
