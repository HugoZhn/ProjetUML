package model;

public class Parametres {

    double coefCorrectifV;
    double coefCorrectifC;

    /**
     * Constructeur de la classe Parametres
     *
     * @param cV double : coefficient correcteur d'une voiture
     * @param cC double : coefficient correcteur d'un camion
     */
    public Parametres(double cV, double cC) {
        this.coefCorrectifC = cC;
        this.coefCorrectifV = cV;
    }

    /**
     * Méthode qui permet de calculer le coefficient correcteur d'une voiture en
     * fonction de sa puissance en chevaux (base = 200 Cv)
     *
     * @param puissanceV integer : puissance de la voiture du participant
     * @return double : coefficient correcteur pour une voiture
     */
    public double getCoefCorrectifV(int puissanceV) {
        int ecart = puissanceV - 200;
        double disV = 1 + (ecart * this.coefCorrectifV);
        return disV;
    }

    /**
     * Méthode qui permet de calculer le coefficient correcteur d'un camion en
     * fonction de son poids (base = 2000kg)
     *
     * @param poidsV double : poids du camion du participant
     * @return double : coefficient correcteur pour un camion
     */
    public double getCoefCorrectifC(double poidsV) {
        int ecart = (int) ((2000 - poidsV) / 100);
        double disC = 1 + (ecart * this.coefCorrectifC);
        return disC;
    }

}
