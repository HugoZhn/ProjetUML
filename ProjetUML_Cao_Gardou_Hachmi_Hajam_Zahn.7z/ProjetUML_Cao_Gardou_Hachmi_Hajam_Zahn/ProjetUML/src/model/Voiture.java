package model;

public class Voiture extends Vehicule {

    private int puissanceV;

    /**
     * Constructeur de Voiture
     * @param idV String : immatriculation de la voiture 
     * @param mod String : modele de la voiture
     * @param puiV integer : puissance d'une voiture
     */
    public Voiture(String idV, String mod, int puiV) {
        super(idV, mod);
        this.puissanceV = puiV;
    }

    /**
     * Implémantation de la méthode abstraite qui permet de récuperer le coefficient correcteur d'une voiture (héritée de véhicule)
     */
    @Override
    public double getCoeffCorrecteur() {
        return super.para.getCoefCorrectifV(this.puissanceV);
    }
}
