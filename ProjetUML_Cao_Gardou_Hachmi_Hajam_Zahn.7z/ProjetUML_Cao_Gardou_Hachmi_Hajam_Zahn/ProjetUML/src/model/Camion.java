package model;

public class Camion extends Vehicule {

    private double poidsV;

    /**
     * Constructeur de Camion
     * @param idV String : immatriculation du camion 
     * @param mod String : modele du camion
     * @param pV float : poids d'un camion
     */
    public Camion(String idV, String mod, float pV) {
        super(idV, mod);
        this.poidsV = pV;
    }

    @Override
    /**
     * Implémantation de la méthode abstraite qui permet de récuperer le coefficient correcteur d'un camion (héritée de véhicule)
     */
    public double getCoeffCorrecteur() {
        return super.para.getCoefCorrectifC(this.poidsV);
    }

}
