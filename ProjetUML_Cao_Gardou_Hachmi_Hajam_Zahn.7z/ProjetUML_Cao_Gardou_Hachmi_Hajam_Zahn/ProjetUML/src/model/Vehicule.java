package model;

public abstract class Vehicule {

    protected String idVehicule;
    protected String modele;
    protected Parametres para;

    /**
     * Constucteur de la classe abstraite Vehicule
     * @param idV : String : numéro d'immatriculation d'un véhicule
     * @param modele : String : modèle d'un véhicule
     */
    public Vehicule(String idV, String modele) {
        this.idVehicule = idV;
        this.modele = modele;
        this.para = new Parametres(0.005, 0.1);
    };
	
    /**
     * Méthode abstraite permettant de récupérer le coefficient correcteur d'un véhicule
     * Elle sera héritée par les classes filles Voiture et Camion
     * @return double : coefficient correcteur
     */
    public abstract double getCoeffCorrecteur();

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idVehicule == null) ? 0 : idVehicule.hashCode());
        return result;
    }

    /**
     * Méthode permettant de comparer la valeur de deux instances, deux vehicules sont les mêmes s'ils ont le même id
     * @param obj
     * @return boolean : égalité ou non entre les instances
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Vehicule other = (Vehicule) obj;
        if (idVehicule == null) {
            if (other.idVehicule != null) {
                return false;
            }
        } else if (!idVehicule.equals(other.idVehicule)) {
            return false;
        }
        return true;
    }

}
