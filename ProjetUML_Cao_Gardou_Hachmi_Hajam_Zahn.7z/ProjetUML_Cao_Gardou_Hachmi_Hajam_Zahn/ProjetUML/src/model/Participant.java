package model;

import utilitaire.Date;
import utilitaire.Etat;

public class Participant {

    private int noInscription;
    private Date dateInscription;
    private double tempsFinal;
    private boolean disqualifie;

    private Coureur coureur;
    private Edition edition;
    private Vehicule vehicule;
    
    private String etat; 

    /**
     * Constructeur d'un participant. Numéro d'inscription saisi automatiquement.
     * @param vehiculeUtilise Un participant utilise un véhicule
     * @param editionParticipe et participe à une édition
     * @param coureurParticipant  et correspond à un coureur
     */
    public Participant(Vehicule vehiculeUtilise, Edition editionParticipe, Coureur coureurParticipant) {

        this.noInscription = editionParticipe.getParticipants().size();
        this.edition = editionParticipe;
        editionParticipe.getParticipants().add(this);

        this.dateInscription = new Date();
        this.vehicule = vehiculeUtilise;
        this.coureur = coureurParticipant;

        this.tempsFinal = 0;
        this.disqualifie = false;
        
        this.etat = Etat.ATTENTE;
    }

    /**
     * Constructeur d'un participant ayant son inscription validé
     * @param noInscr numéro d'inscription saisi
     * @param vehiculeUtilise Un participant utilise un véhicule
     * @param editionParticipe et participe à une édition
     * @param coureurParticipant  et correspond à un coureur
     */
    public Participant(int noInscr, Vehicule vehiculeUtilise, Edition editionParticipe, Coureur coureurParticipant) {

        this.noInscription = noInscr;
        this.edition = editionParticipe;
        editionParticipe.getParticipants().add(this);

        this.dateInscription = new Date();
        this.vehicule = vehiculeUtilise;
        this.coureur = coureurParticipant;

        this.tempsFinal = 0;
        this.disqualifie = false;
        
        this.etat = Etat.ATTENTE;
    }
    
    /**
     * Constructeur d'un participant ayant son inscription validé
     * @param noInscr numéro d'inscription saisi
     * @param vehiculeUtilise Un participant utilise un véhicule
     * @param editionParticipe et participe à une édition
     * @param coureurParticipant  et correspond à un coureur
     * @param etat etat de validation de l'inscription saisi manuellement
     */
    public Participant(int noInscr, Vehicule vehiculeUtilise, Edition editionParticipe, Coureur coureurParticipant, String etat) {

        this.noInscription = noInscr;
        this.edition = editionParticipe;
        editionParticipe.getParticipants().add(this);

        this.dateInscription = new Date();
        this.vehicule = vehiculeUtilise;
        this.coureur = coureurParticipant;

        this.tempsFinal = 0;
        this.disqualifie = false;
        
        this.etat = etat;
    }

    public Edition getEdition() {
        return edition;
    }

    public String getEtat() {
        return etat;
    }

    public int getNoInscription() {
        return noInscription;
    }

    public Vehicule getVehicule() {
        return this.vehicule;
    }

    public Coureur getCoureur() {
        return this.coureur;
    }

    public Date getDateInscription() {
        return dateInscription;
    }

    public double getTempsFinal() {
        this.calculerTempsFinal();
        return tempsFinal;
    }
    
    /**
     * Permet de valider l'inscription d'un participant
     */
    public void validerInscr(){
        this.etat = Etat.VALIDE;
    }
    
     /**
     * Permet de refuser l'inscription d'un participant
     */
    public void refuserInscr(){
        this.etat = Etat.REFUSE;
    }

    /**
     * Renvoie le coefficient correcteur du véhicule associé à l'inscription
     * @return coefficient correcteur du véhicule associé
     */
    public double getCoeffCorrecteurVehicule() {
        return this.vehicule.getCoeffCorrecteur();
    }

    /**
     * Indique si un participant est disqualifié ou non
     * @return true si un participant est disqualifié, false sinon
     */
    public boolean prendreDepart() {
        return !(this.disqualifie);
    }

    /**
     * Permet de disalifier un participant
     */
    public void disqualifier() {
        this.disqualifie = true;
    }
    
    /**
     * Méthode permettant de corriger les temps.
     */
    public void calculerTempsFinal() {
        if (!this.disqualifie) {
            this.tempsFinal = 0;
            for (Etape et : this.edition.getEtapes()) {
                if (et.getCourirTempsCorriges().containsKey(this)) {
                    this.tempsFinal += et.getCourirTempsCorriges().get(this);
                }
            }
        }
    }

    public String toString() {
        return "N° " + this.noInscription + " - " + this.coureur.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((coureur == null) ? 0 : coureur.hashCode());
        result = prime * result + ((dateInscription == null) ? 0 : dateInscription.hashCode());
        result = prime * result + ((edition == null) ? 0 : edition.hashCode());
        result = prime * result + noInscription;
        result = prime * result + ((vehicule == null) ? 0 : vehicule.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Participant other = (Participant) obj;
        if (coureur == null) {
            if (other.coureur != null) {
                return false;
            }
        } else if (!coureur.equals(other.coureur)) {
            return false;
        }
        if (dateInscription == null) {
            if (other.dateInscription != null) {
                return false;
            }
        } else if (!dateInscription.equals(other.dateInscription)) {
            return false;
        }
        if (edition == null) {
            if (other.edition != null) {
                return false;
            }
        } else if (!edition.equals(other.edition)) {
            return false;
        }
        if (noInscription != other.noInscription) {
            return false;
        }
        if (vehicule == null) {
            if (other.vehicule != null) {
                return false;
            }
        } else if (!vehicule.equals(other.vehicule)) {
            return false;
        }
        return true;
    }

}
