package controler;

import java.io.*;
import model.*;

import utilitaire.Connexion;
import utilitaire.Auth;
import utilitaire.DataHandler;
import utilitaire.Date;
import utilitaire.Etat;
import utilitaire.Libelle;
import vue.*;

/**
 * la classe permet de controler la connexion entre les vues,
 * et sauvegarder les nouvelles données dans la base de données
 * et charger les nouvelles données dans les classes
 * @author caoyang
 */
public class Controler {

    DataHandler dataExtractor;
    Connexion conn;

    public Controler() {
        this.conn = new Connexion();
        this.dataExtractor = new DataHandler();
    }

    public DataHandler getDataExtractor() {
        return dataExtractor;
    }

    /**
     * verifier si la connexion est validée
     * @param em email
     * @param mdp mot de passe
     */
    public void ConnValider(String em, String mdp) {
        if (this.conn.checkConn(em, mdp)) {
            if (this.conn.getAuth(em).equals(Auth.USER)) {
                VueInscriptions vInscr = new VueInscriptions(this,em);
                vInscr.setVisible(true);
            } else {
                System.err.println("ATTENTE!!!");
            }
        } else {
            VueConnexion vConn = new VueConnexion(this,true);
            vConn.setVisible(true);
        };
    }

    public String getAuth(String em) {
        return this.conn.getAuth(em);
    }

    public void InscrireCompte() {
        VueInscrireCompte vIC = new VueInscrireCompte(this);
        vIC.setVisible(true);
    }

    public void InscrireEdition(String em) {
        VueInscrireEdition vIE = new VueInscrireEdition(this,em);
        vIE.setVisible(true);
    }

    public void VueInscriptions(String em) {
        VueInscriptions vInscr = new VueInscriptions(this,em);
        vInscr.setVisible(true);
    }

    public void Deconnecter() {
        VueConnexion vConn = new VueConnexion(this,false);
        vConn.setVisible(true);
    }

    public void vueRallyes(String em) {
        VueRallye vR = new VueRallye(this,em);
        vR.setVisible(true);
    }

    /**
     * sauvegarder la nouvelle connexion de l'application et changer la vue
     * @param em email
     * @param mdp mot de passe
     * @param nom nom de coureur
     * @param prenom prenom du coureur
     * @param sexe civilité du coureur
     * @param dateNaissance date de naissance de coureur
     * @param groupeS groupe sanguim
     * @param nationalite nationalité du coureur
     */
    public void SaveInscrireCompte(String em, String mdp, String nom, String prenom, String sexe, String dateNaissance, String groupeS, String nationalite) {
        PrintWriter pw;

        //save connxion
        String filepathConn = "./data/new/Connexion.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathConn, true));
            pw.println(em + ";" + mdp + ";" + Auth.USER);
            pw.flush();
            pw.close();
            this.conn.addNewConn(em, mdp, Auth.USER);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        //save coureur
        String filepathC = "./data/new/Coureurs.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathC, true));
            pw.println(nom + ";" + prenom + ";" + sexe + ";" + dateNaissance + ";" + groupeS + ";" + nationalite);
            pw.flush();
            pw.close();
            this.dataExtractor.getCoureurs().put(em, new Coureur(nom, prenom, new Date(dateNaissance), nationalite, groupeS, sexe));
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        VueConnexion vConn = new VueConnexion(this,false);
        vConn.setVisible(true);
    }

    /**
     * sauvegarder l'inscription d'un rallye avec édition choisi
     * @param NoI le numéro d'inscription
     * @param nomRallye le nom du rallye
     * @param noEdition le numéro de l'édition
     * @param mail l'email
     * @param idVehicule l'immatriculation
     * @param modele le modèle de la véhicule
     * @param type le type de véhicule
     * @param puissance la puissance si le type est voiture
     * @param poids le poids si le type est camion
     */
    public void SaveInscrireEdition(int NoI, String nomRallye, String noEdition, String mail, String idVehicule, String modele, String type, String puissance, String poids) {
        saveVehicule(idVehicule, modele, type, puissance, poids);
        saveParticipant(NoI, nomRallye, noEdition, mail, idVehicule);

        VueInscriptions vInscr = new VueInscriptions(this,mail);
        vInscr.setVisible(true);
    }

    /**
     * sauvegarder la véhicule
     * @param idV l'immatriculation
     * @param modele le modèle 
     * @param type le type de véhicule (voiture ou camion)
     * @param puissance la puissance si le type est voiture
     * @param poids le poids si le type est camion
     */
    public void saveVehicule(String idV, String modele, String type, String puissance, String poids) {
        PrintWriter pw;

        String filepathVehicule = "./data/new/Vehicule.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            if (type.equals(Libelle.VOITURE)) {
                poids = "0";
            } else if (type.equals(Libelle.CAMION)) {
                puissance = "0";
            }
            pw.println(idV + ";" + modele + ";" + type + ";" + puissance + ";" + poids);
            pw.flush();
            pw.close();
            if (type.equals(Libelle.VOITURE)) {
                this.dataExtractor.getVehicules().put(idV, new Voiture(idV, modele, Integer.parseInt(puissance)));
            } else if (type.equals(Libelle.CAMION)) {
                this.dataExtractor.getVehicules().put(idV, new Camion(idV, modele, Integer.parseInt(poids)));
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * sauvegarder le nouveau rallye
     * @param nom le nom du rallye
     * @param ville la ville du rallye
     * @param pays le pays du rallye
     */
    public void saveRallye(String nom, String ville, String pays) {
        PrintWriter pw;

        String filepathVehicule = "./data/new/Rallye.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(nom + ";" + ville + ";" + pays);
            pw.flush();
            pw.close();
            this.dataExtractor.getRallyes().put(nom, new Rallye(nom, ville, pays));
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * sauvegarder la nouvelle édition
     * @param nomRallye le nom du rallye de l'édition
     * @param noEdition le numéro de l'édition
     * @param dateDeb la date de débute de l'édition
     * @param dateFin la date de fin de l'éditon
     */
    public void saveEdition(String nomRallye, String noEdition, String dateDeb, String dateFin) {
        PrintWriter pw;

        String filepathVehicule = "./data/new/Edition.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(nomRallye + ";" + noEdition + ";" + dateDeb + ";" + dateFin);
            pw.flush();
            pw.close();
            Rallye thisRallye = null;
            if (this.dataExtractor.getRallyes().containsKey(nomRallye)) {
                thisRallye = this.dataExtractor.getRallyes().get(nomRallye);
            }
            String cle = nomRallye + "_" + noEdition;
            this.dataExtractor.getEditions().put(cle, new Edition(thisRallye, new Date(dateDeb), new Date(dateFin)));
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * sauvegarder le nouveau participant
     * @param noI le numéro de participant
     * @param nomRallye le nom du rallye du participant
     * @param noEdition le numéro de l'édition du participant
     * @param mail l'email
     * @param idVehicule l'immatriculation
     */
    public void saveParticipant(int noI, String nomRallye, String noEdition, String mail, String idVehicule) {
        PrintWriter pw;

        String filepathVehicule = "./data/new/Participant.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(Integer.toString(noI) + ";" + nomRallye + ";" + noEdition + ";" + mail + ";" + idVehicule + ";" + Etat.ATTENTE);
            pw.flush();
            pw.close();

            Edition thisEdition = null;
            String cleEd = nomRallye + "_" + noEdition;
            if (this.dataExtractor.getEditions().containsKey(cleEd)) {
                thisEdition = this.dataExtractor.getEditions().get(cleEd);
            }

            Coureur thisCoureur = null;
            if (this.dataExtractor.getCoureurs().containsKey(mail)) {
                thisCoureur = this.dataExtractor.getCoureurs().get(mail);
            }

            Vehicule thisVehicule = null;
            if (this.dataExtractor.getVehicules().containsKey(idVehicule)) {
                thisVehicule = this.dataExtractor.getVehicules().get(idVehicule);
            }

            String cle = mail + "_" + nomRallye + "_" + noEdition;
            this.dataExtractor.getParticipants().put(cle, new Participant(noI, thisVehicule, thisEdition, thisCoureur, Etat.ATTENTE));

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

}
