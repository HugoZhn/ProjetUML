package utilitaire;

import java.util.ArrayList;
import model.*;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

//Classe gérant l'affichage graphique de type "PieChart"
public class Camembert extends JFrame {

	private static final long serialVersionUID = 1L;
	Rallye rallye;

	public Camembert(Rallye rallyec, String chartTitle, Edition ed) {        
		this.rallye =rallyec  ;
		// Création de la dataset
		PieDataset dataset = createDataset(ed);
		// Création de la charte par rapport à la dataset
		JFreeChart chart = createChart(dataset, chartTitle);
		ChartPanel chartPanel = new ChartPanel(chart);
		// Dimension par défaut
		chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
		// Ajouter à l'app
		setContentPane(chartPanel);
	}

	// Créer le dataset
	private  PieDataset createDataset(Edition ed) {
		double nombreHommes = 0;
		ArrayList<Participant> participants = ed.getParticipants();
		for(int i=0; i<participants.size(); i++) {
			if(participants.get(i).getCoureur().getSexe().equals("H")) {
				nombreHommes=nombreHommes+1;			
			}
		}
		DefaultPieDataset result = new DefaultPieDataset();
		result.setValue("Hommes", nombreHommes);
		result.setValue("Femmes", participants.size()-nombreHommes);
		return result;
	}

	// Créer la charte
	private JFreeChart createChart(PieDataset dataset, String title) {
		JFreeChart chart = ChartFactory.createPieChart3D(
				title,                  // chart title
				dataset,                // data
				true,                   // include legend
				true,
				false
				);

		PiePlot3D plot = (PiePlot3D) chart.getPlot();
		plot.setStartAngle(300);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha(0.6f);
		return chart;
	}
}