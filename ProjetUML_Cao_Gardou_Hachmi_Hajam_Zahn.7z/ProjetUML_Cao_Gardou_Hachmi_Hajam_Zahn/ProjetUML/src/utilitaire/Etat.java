package utilitaire;

public final class Etat {
    public static final String ENCOURS = "En cours";
    public static final String ATTENTE = "En attente";
    public static final String VALIDE = "Validée";
    public static final String REFUSE = "Refusée";
}
