package utilitaire;

public final class Civilite {
    public static final String MONSIEUR = "M.";
    public static final String MADAME = "Mme.";
    public static final String HOMME = "H";
    public static final String FEMME = "F";
}
