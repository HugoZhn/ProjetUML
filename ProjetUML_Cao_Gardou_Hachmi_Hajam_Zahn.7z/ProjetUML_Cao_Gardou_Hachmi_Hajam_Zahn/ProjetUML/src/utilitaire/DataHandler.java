package utilitaire;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

import model.Camion;
import model.Coureur;
import model.Edition;
import model.Participant;
import model.Rallye;
import model.Vehicule;
import model.Voiture;

/**
 * la classe permet de connecter la base de données et l'extraire
 */
public class DataHandler {

    private Scanner scanner;
    private HashMap<String, Vehicule> vehicules;
    private HashMap<String, Coureur> coureurs;
    private HashMap<String, Rallye> rallyes;
    private HashMap<String, Edition> editions;
    private HashMap<String, Participant> participants;

    public DataHandler() {
        this.vehicules = new HashMap<>();
        this.coureurs = new HashMap<>();
        this.rallyes = new HashMap<>();
        this.editions = new HashMap<>();
        this.participants = new HashMap<>();

        try {
            this.openDB();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public HashMap<String, Vehicule> getVehicules() {
        return vehicules;
    }

    public HashMap<String, Coureur> getCoureurs() {
        return coureurs;
    }

    public HashMap<String, Rallye> getRallyes() {
        return rallyes;
    }

    public HashMap<String, Edition> getEditions() {
        return editions;
    }

    public HashMap<String, Participant> getParticipants() {
        return participants;
    }

    /**
     * extraire les connexions dans la base de données
     * @param conn connexion
     * @param filepath chemin de base de données
     * @throws FileNotFoundException 
     */
    public void extractConn(Connexion conn, String filepath) throws FileNotFoundException {

        this.scanner = new Scanner(new File(filepath));

        int i = 0;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] fields = line.split(";");
            if (i != 0) {
                String em = fields[0];
                String mdp = fields[1];
                String auth = fields[2];
                conn.addNewConn(em, mdp, auth);
            }
            i++;
        }
        scanner.close();
    }

    /**
     * extraire toutes les données pour les classes (Véhicule, coureur, rallye, édition, participant)
     * @throws FileNotFoundException 
     */
    public void openDB() throws FileNotFoundException {

        // Vehicules
        this.scanner = new Scanner(new File("./data/new/Vehicule.csv"));
        String line = scanner.nextLine();
        String[] fields;

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            fields = line.split(";");
            String idV = fields[0];
            String modele = fields[1];
            String type = fields[2];
            String puissance = fields[3];
            String poids = fields[4];
            if (type.equals("Voiture")) {
                Voiture newV = new Voiture(idV, modele, Integer.parseInt(puissance));
                this.vehicules.put(idV, newV);
            } else if (type.equals("Camion")) {
                Camion newC = new Camion(idV, modele, Integer.parseInt(poids));
                this.vehicules.put(idV, newC);
            }
        }

        // Coureurs
        this.scanner = new Scanner(new File("./data/new/Coureur.csv"));
        line = scanner.nextLine();

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            fields = line.split(";");
            String mail = fields[0];
            String nom = fields[1];
            String prenom = fields[2];
            String dateNaiss = fields[3];
            String nationalite = fields[4];
            String gpSang = fields[5];
            String sexe = fields[6];
            this.coureurs.put(mail, new Coureur(nom, prenom, new Date(dateNaiss), nationalite, gpSang, sexe));
        }

        // Rallyes
        this.scanner = new Scanner(new File("./data/new/Rallye.csv"));
        line = scanner.nextLine();

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            fields = line.split(";");
            String nom = fields[0];
            String ville = fields[1];
            String pays = fields[2];
            this.rallyes.put(nom, new Rallye(nom, ville, pays));
        }

        // Editions
        this.scanner = new Scanner(new File("./data/new/Edition.csv"));
        line = scanner.nextLine();

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            fields = line.split(";");
            String nomRallye = fields[0];
            String noEdition = fields[1];
            String datDeb = fields[2];
            String datFin = fields[3];
            Rallye thisRallye = null;
            for (Rallye ra : this.rallyes.values()) {
                if (ra.getNomRallye().equals(nomRallye)) {
                    thisRallye = ra;
                }
            }
            String cle = nomRallye + "_" + noEdition;
            this.editions.put(cle, new Edition(thisRallye, new Date(datDeb), new Date(datFin)));
        }

        // Participants
        this.scanner = new Scanner(new File("./data/new/Participant.csv"));
        line = scanner.nextLine();

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            fields = line.split(";");
            String noInscr = fields[0];
            String nomRallye = fields[1];
            String noEdition = fields[2];
            String email = fields[3];
            String idV = fields[4];
            String etat = fields[5];

            Edition thisEdition = null;
            String cleed = nomRallye + "_" + noEdition;
            if(this.editions.containsKey(cleed)){
                thisEdition = this.editions.get(cleed);
            }
            
            Coureur thisCoureur = null;
            if(this.coureurs.containsKey(email)){
                thisCoureur = this.coureurs.get(email);
            }
            
            Vehicule thisVehicule = null;
            if(this.vehicules.containsKey(idV)){
                thisVehicule = this.vehicules.get(idV);
            }

            String cle = email + "_" + nomRallye + "_" + noEdition;
            this.participants.put(cle, new Participant(Integer.parseInt(noInscr), thisVehicule, thisEdition, thisCoureur, etat));
        }
    }

}
