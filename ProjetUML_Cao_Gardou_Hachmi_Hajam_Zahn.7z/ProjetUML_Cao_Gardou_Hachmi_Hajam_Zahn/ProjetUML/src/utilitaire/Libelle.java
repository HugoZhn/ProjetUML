package utilitaire;

public final class Libelle {
    //button
    public static final String DECONNECTER = "Se déconnecter";
    public static final String SAVE = "Save";
    public static final String VALIDER = "Valider";
    public static final String ANNULER = "Annuler";
    public static final String ENVOYER = "Envoyer";
    
    //label
    public static final String VIDE = "";
    
    public static final String SINSCRIRE = "S'incrire";
    
    public static final String EMAIL = "Adresse e-mail :";
    public static final String MDP = "Mot de passe :";
    
    public static final String NOM = "Nom :";
    public static final String PRENOM = "Prenom :";
    public static final String DATENAISSANCE = "Date de naissance :";
    public static final String GROUPESANGUIN = "Groupe sanguin :";
    public static final String NATIONALITE = "Nationalité :";
    public static final String SEXE = "Civilité :";
    
    public static final String INSCRIPTION_COUREUR = "Vos inscriptions";
    
    public static final String RALLYES = "Rallyes";
    public static final String ADD = "+";
    
    public static final String INSCRIPTION = "Inscription";
    public static final String STATUT = "Statut :";
    
    public static final String RALLYE = "Rallye :";
    public static final String EDITION = "Edition :";
    public static final String PAYS = "Pays :";
    public static final String VILLE = "Ville :";
    public static final String DATES = "Dates :";
    public static final String DATEDEB = "Date Début :";
    public static final String DATEFIN = "Date Fin :";
    
    public static final String COUREUR = "Coureur";
    public static final String VEHICULE = "Véhicule";
    public static final String IMMATRICULATION = "Immatriculation :";
    public static final String MODEL = "Model :";
    public static final String VOITURE = "Voiture";
    public static final String CAMION = "Camion";
    public static final String PUISSANCE = "Puissance :";
    public static final String POIDS = "Poids :";
    
    //erreur
    public static final String ERR_EMAIL_MDP = "Votre email ou mot de passe n'est pas correct, veuillez réessayer";
    public static final String ERR_EMAIL = "Veuillez saisir votre adresse e-mail";
    public static final String ERR_MDP = "Veuillez saisir votre mot de passe";
    public static final String ERR_EMAIL_MDP_SAISIE = "Veuillez saisir votre adresse e-mail et mot de passe";
    public static final String ERR_SAISIR_DONNEES= "Veuillez saisir toutes vos données";
    
    //normal
    public static final String BIENVENUE = "Bienvenue sur le site de la FFRAG";
    public static final String CONNEXION = "Connexion FFRAG";
}
