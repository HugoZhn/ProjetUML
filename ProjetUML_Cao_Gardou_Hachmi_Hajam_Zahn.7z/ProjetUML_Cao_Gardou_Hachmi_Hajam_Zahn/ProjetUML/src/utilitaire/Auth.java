package utilitaire;

public final class Auth {
    public static final String USER = "Coureur";
    public static final String JURY = "Jury";
    public static final String ORGANISATEUR = "Organisateur";
    public static final String PARTENAIRE = "Partenaire";
}
