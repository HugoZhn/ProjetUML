package exceptions;

public class ExceptionParis extends Exception{

    public ExceptionParis(int code) {
        switch (code) {
            case 1:
                System.err.println("Erreur : Vous ne pouvez pas parier sur une édition terminée");
                break;
            case 2:
                System.err.println("Erreur : Vous ne pouvez pas parier sur une étape terminée");
                break;
        }
    }
}
