/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.io.*;

import utilitaire.Connexion;
import utilitaire.Auth;
import utilitaire.DataHandler;
import utilitaire.Etat;
import utilitaire.Libelle;
import vue.*;

/**
 *
 * @author caoyang
 */
public class Controler {
    
    DataHandler dataExtractor;
    Connexion conn;
    
    public Controler(){
        this.conn = new Connexion();
        this.dataExtractor = new DataHandler();
    }

    public DataHandler getDataExtractor() {
        return dataExtractor;
    }
    
    public void ConnValider(String em, String mdp){
        if(this.conn.checkConn(em, mdp)){
            if(this.conn.getAuth(em).equals(Auth.USER)){
                VueInscriptions vInscr = new VueInscriptions(em);
                vInscr.setVisible(true);          
            } else {
                System.err.println("ATTENTE!!!");
            }
        } else {
            VueConnexion vConn = new VueConnexion(true);
            vConn.setVisible(true);
        };
    }
    
    public String getAuth(String em){
        return this.conn.getAuth(em);
    }
    
    public void InscrireCompte(){
        VueInscrireCompte vIC = new VueInscrireCompte();
        vIC.setVisible(true);
    }
    
    public void InscrireEdition(String em){
        VueInscrireEdition vIE = new VueInscrireEdition(em);
        vIE.setVisible(true);
    }
    
    public void VueInscriptions(String em){
        VueInscriptions vInscr = new VueInscriptions(em);
        vInscr.setVisible(true);          
    }
    
    public void Deconnecter(){
        VueConnexion vConn = new VueConnexion(false);
        vConn.setVisible(true);
    }
    
    public void vueRallyes(String em){
        VueRallye vR = new VueRallye(em);
        vR.setVisible(true);
    }
    
    public void SaveInscrireCompte(String em, String mdp,String nom, String prenom, String sexe, String dateNaissance, String groupeS, String nationalite){
        PrintWriter pw;
        
        //save connxion
        String filepathConn = "./data/new/Connexion.csv";
        try{
            pw = new PrintWriter(new FileOutputStream(filepathConn,true));
            pw.println(em+";"+mdp+";"+Auth.USER);
            pw.flush();
            pw.close();
        }catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        
        //save coureur
        String filepathC = "./data/new/Coureurs.csv";
        try{            
            pw = new PrintWriter(new FileOutputStream(filepathC,true));
            pw.println(nom+";"+prenom+";"+sexe+";"+dateNaissance+";"+groupeS+";"+nationalite);
            pw.flush();
            pw.close();
        }catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        
        VueConnexion vConn = new VueConnexion(false);
        vConn.setVisible(true);
    }
    
    public void SaveInscrireEdition(int NoI, String nomRallye, String noEdition, String mail, String idVehicule, String modele, String type, String puissance, String poids){
        saveVehicule(idVehicule, modele, type, puissance, poids);
        saveParticipant(NoI, nomRallye, noEdition, mail, idVehicule);
        
        VueInscriptions vInscr = new VueInscriptions(mail);
        vInscr.setVisible(true);
    }
    
    public void saveVehicule(String idV, String modele, String type, String puissance, String poids) {
        PrintWriter pw;

        String filepathVehicule = "./data/new/Vehicule.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            if (type.equals(Libelle.VOITURE)) {
                poids = "0";
            } else if (type.equals(Libelle.CAMION)) {
                puissance = "0";
            }
            pw.println(idV + ";" + modele + ";" + type + ";" + puissance + ";" + poids);
            pw.flush();
            pw.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveRallye(String nom, String ville, String pays){
        PrintWriter pw;

        String filepathVehicule = "./data/new/Rallye.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(nom + ";" + ville + ";" + pays);
            pw.flush();
            pw.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveEdition(String nomRallye, String noEdition, String dateDeb, String dateFin){
        PrintWriter pw;

        String filepathVehicule = "./data/new/Edition.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(nomRallye + ";" + noEdition + ";" + dateDeb + ";" + dateFin);
            pw.flush();
            pw.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public void saveParticipant(int NoI, String nomRallye, String noEdition, String mail, String idVehicule){
        PrintWriter pw;
        
        String filepathVehicule = "./data/new/Participant.csv";
        try {
            pw = new PrintWriter(new FileOutputStream(filepathVehicule, true));
            pw.println(Integer.toString(NoI)+";"+nomRallye + ";" + noEdition + ";" + mail + ";" + idVehicule+ ";"+Etat.ATTENTE);
            pw.flush();
            pw.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
   
}
