/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilitaire;

/**
 *
 * @author caoyang
 */
public final class Civilite {
    public static final String MONSIEUR = "M.";
    public static final String MADAME = "Mme.";
    public static final String HOMME = "H";
    public static final String FEMME = "F";
}
